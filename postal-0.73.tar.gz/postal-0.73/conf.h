/* conf.h.  Generated from conf.h.in by configure.  */
#ifndef CONF_H
#define CONF_H

#define HAVE_VECTOR 1
#define HAVE_EXT_HASH_MAP 1

#endif
